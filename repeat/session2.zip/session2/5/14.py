age = int(input("Enter ur age: "))

if age>=18:
    print("you are an adult")
else:
    print("you are a minor")